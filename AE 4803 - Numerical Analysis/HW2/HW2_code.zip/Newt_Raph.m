%% AE 4803 - HW 2 - Q1_d
% By: Noe Lepez Da Silva Duarte
% Date: 02 Feb. 2022

function [x_n, iter] = Newt_Raph(x0, error, func, func_prime)

iter = [];
x_p = x0;
Ea = 100;

while(Ea >= error) 
       % Compute new solution.
       x_n = x_p - func(x_p)/func_prime(x_p);
        
       % Compute current solution tolerance.
       Ea = abs((x_n-x_p)/x_n);
       
       % Update Solutions
       x_p = x_n;
       iter = [iter, x_n];
end
end